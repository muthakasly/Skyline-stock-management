# Skyline-stock-management
stock management system user name admin password admin
